#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — ACTION BUTTON SCRIPT
#  Developer : Gailo Willy | v1.0.0
#  Trigger   : User taps Action button inside AxManager App
#  Shell     : BusyBox ASH Standalone
# ═══════════════════════════════════════════════════════════════

MODDIR=${0%/*}
LOG=/data/local/tmp/hyperax_action.log

log() { echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG"; }

log "========================================="
log " HYPER AX MANAGER — MANUAL BOOST TRIGGER"
log " Developer: Gailo Willy"
log "========================================="

# Re-run full engine
sh "$MODDIR/scripts/auto_apply.sh"

log "MANUAL BOOST APPLIED SUCCESSFULLY"
log "Max CPU | Max GPU | Max Hz | FPS Unlocked"
