#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — POST-FS-DATA SCRIPT
#  Developer : Gailo Willy | v1.0.0
#  Trigger   : BOOT_COMPLETED first sync (AxManager)
#  Shell     : BusyBox ASH Standalone
#  Note      : Runs BEFORE service.sh — early init tweaks here
# ═══════════════════════════════════════════════════════════════

MODDIR=${0%/*}

# ── EARLY BOOT: VM + I/O TWEAKS ─────────────────────────────
# These are applied first before service.sh engine runs

# I/O Scheduler — set to performance for all block devices
for blk in /sys/block/*/queue/scheduler; do
    echo "none" > "$blk" 2>/dev/null || echo "mq-deadline" > "$blk" 2>/dev/null
done

# Read-ahead buffer
for ra in /sys/block/*/queue/read_ahead_kb; do
    echo 128 > "$ra" 2>/dev/null
done

# Disable I/O stats collection (reduces latency)
for iostats in /sys/block/*/queue/iostats; do
    echo 0 > "$iostats" 2>/dev/null
done

# ── EARLY PROP SETS ─────────────────────────────────────────
setprop debug.sf.hw 1              2>/dev/null
setprop debug.egl.hw 1             2>/dev/null
setprop debug.performance.tuning 1 2>/dev/null
setprop persist.sys.performance_mode 1 2>/dev/null

# ── LOG ─────────────────────────────────────────────────────
echo "[$(date '+%H:%M:%S')] post-fs-data.sh executed" \
    >> /data/local/tmp/hyperax_apply.log 2>/dev/null
