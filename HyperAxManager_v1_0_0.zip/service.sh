#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — SERVICE SCRIPT
#  Developer : Gailo Willy | v1.0.0
#  Trigger   : BOOT_COMPLETED late_start (AxManager)
#  Shell     : BusyBox ASH Standalone
# ═══════════════════════════════════════════════════════════════

MODDIR=${0%/*}

# Wait for boot to fully complete
sleep 10

# Run main engine
sh "$MODDIR/scripts/auto_apply.sh"

# Launch game boost monitor in background
sh "$MODDIR/scripts/game_boost.sh" &
