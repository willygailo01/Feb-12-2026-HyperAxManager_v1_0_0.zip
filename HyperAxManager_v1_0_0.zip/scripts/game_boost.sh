#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — GAME BOOST ENGINE
#  Developer : Gailo Willy | v1.0.0
#  Trigger   : action.sh button OR auto game detection
#  Shell     : BusyBox ASH Standalone
# ═══════════════════════════════════════════════════════════════

MODDIR=${0%/*}
LOG=/data/local/tmp/hyperax_gameboost.log

log() { echo "[$(date '+%H:%M:%S')] $1" >> "$LOG"; }
write() { [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }
prop() { setprop "$1" "$2" 2>/dev/null; }

# ── GAME PACKAGE LIST ───────────────────────────────────────
GAME_PACKAGES="
com.mobilelegends.mi
com.tencent.ig
com.pubg.krmobile
com.activision.callofduty.shooter
com.garena.game.freefire
com.miHoYo.GenshinImpact
com.epicgames.fortnite
com.roblox.client
com.proxima.era
com.shantigames.ml.adventure
com.ea.game.nfs14_row
com.supercell.clashofclans
com.supercell.clashroyale
com.tencent.lolm
com.riot.league_of_legends
com.netease.sky
com.miHoYo.Nap
"

# ═══════════════════════════════════════════════════════════════
# FUNCTION: DETECT FOREGROUND GAME
# ═══════════════════════════════════════════════════════════════
get_foreground_pkg() {
    dumpsys window windows 2>/dev/null \
        | grep -E "mCurrentFocus|mFocusedApp" \
        | grep -oE "[a-zA-Z][a-zA-Z0-9_.]*\.[a-zA-Z][a-zA-Z0-9_]*" \
        | head -1
}

# ═══════════════════════════════════════════════════════════════
# FUNCTION: BOOST FOR ACTIVE GAME
# ═══════════════════════════════════════════════════════════════
boost_game() {
    PKG="$1"
    PID=$(pidof "$PKG" 2>/dev/null)

    log "GAME BOOST: $PKG (PID: $PID)"

    # Re-nice game process to max priority
    if [ -n "$PID" ]; then
        renice -20 -p "$PID" 2>/dev/null
        # Set CPU affinity to all BIG cores
        CORE_COUNT=$(nproc)
        MASK=$(printf '%X' $(( (1 << CORE_COUNT) - 1 )))
        taskset -p "0x$MASK" "$PID" 2>/dev/null
        log "Process $PKG reniced to -20, affinity mask: 0x$MASK"
    fi

    # Force max CPU
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
        MAX=$(cat "$cpu/cpuinfo_max_freq" 2>/dev/null)
        write "$cpu/scaling_governor" "performance"
        write "$cpu/scaling_min_freq" "$MAX"
    done

    # Force max GPU (Adreno)
    ADRENO=/sys/class/kgsl/kgsl-3d0
    if [ -d "$ADRENO" ]; then
        write "$ADRENO/default_pwrlevel" "1"
        write "$ADRENO/devfreq/governor" "performance"
        write "$ADRENO/force_clk_on" "1"
        write "$ADRENO/adreno_idler_active" "0"
    fi

    # Force max GPU (Mali)
    for mali in /sys/class/misc/mali0 /sys/devices/platform/*/mali.*/; do
        [ -d "$mali" ] && write "$mali/power_policy" "always_on"
    done

    # Kill background apps (free RAM)
    for bg_pkg in $(pm list packages -3 2>/dev/null | sed 's/package://'); do
        [ "$bg_pkg" = "$PKG" ] && continue
        bg_pid=$(pidof "$bg_pkg" 2>/dev/null)
        [ -n "$bg_pid" ] && kill -9 "$bg_pid" 2>/dev/null
    done

    # Network QoS
    write /proc/sys/net/ipv4/tcp_no_delay_ack 1
    write /proc/sys/net/ipv4/tcp_fastopen 3

    # Lock display Hz
    for hz_node in /sys/class/drm/card0-DSI-1/max_refresh_rate \
                   /sys/class/graphics/fb0/refresh_rate; do
        MAX_HZ=$(cat /sys/class/drm/card0-DSI-1/modes 2>/dev/null \
            | grep -oE '[0-9]+\.[0-9]+' | sort -rn | head -1 | cut -d. -f1)
        [ -z "$MAX_HZ" ] && MAX_HZ=120
        write "$hz_node" "$MAX_HZ"
    done

    prop "persist.game_mode.performance" "2"
    log "BOOST APPLIED FOR: $PKG"
}

# ═══════════════════════════════════════════════════════════════
# AUTO-DETECTION LOOP (runs in background via service.sh)
# ═══════════════════════════════════════════════════════════════
log "GAME BOOST MONITOR STARTED"
LAST_PKG=""

while true; do
    CURRENT=$(get_foreground_pkg)

    if [ -n "$CURRENT" ] && [ "$CURRENT" != "$LAST_PKG" ]; then
        # Check if it's in game list
        if echo "$GAME_PACKAGES" | grep -q "$CURRENT"; then
            boost_game "$CURRENT"
            LAST_PKG="$CURRENT"
        else
            # Not a game — restore balanced mode
            for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
                write "$cpu/scaling_governor" "schedutil"
                MIN=$(cat "$cpu/cpuinfo_min_freq" 2>/dev/null)
                write "$cpu/scaling_min_freq" "$MIN"
            done
            LAST_PKG="$CURRENT"
        fi
    fi

    sleep 5
done
