#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — THERMAL GUARD WATCHDOG
#  Developer : Gailo Willy | v1.0.0
#  Runs as   : Background daemon (launched by auto_apply.sh)
#  Shell     : BusyBox ASH Standalone
# ═══════════════════════════════════════════════════════════════

MODDIR=${0%/*}
LOG=/data/local/tmp/hyperax_thermal.log

log()  { echo "[$(date '+%H:%M:%S')] [THERMAL] $1" >> "$LOG"; }
write(){ [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }
prop() { setprop "$1" "$2" 2>/dev/null; }

# ── THRESHOLDS (°C) ──────────────────────────────────────────
TEMP_WARN=42
TEMP_REDUCE=47
TEMP_THROTTLE=52
TEMP_CRITICAL=58
TEMP_EMERGENCY=63
TEMP_RESUME=45

# ── STATE TRACKING ───────────────────────────────────────────
CURRENT_STATE="performance"

# ── READ TEMPERATURE ─────────────────────────────────────────
get_temp() {
    BEST_TEMP=0
    for zone in /sys/class/thermal/thermal_zone*/temp; do
        [ -f "$zone" ] || continue
        RAW=$(cat "$zone" 2>/dev/null)
        # Kernel reports in millidegrees
        [ "${#RAW}" -gt 4 ] && RAW=$(( RAW / 1000 ))
        [ "$RAW" -gt "$BEST_TEMP" ] && BEST_TEMP="$RAW"
    done
    echo "$BEST_TEMP"
}

# ── ENTER PERFORMANCE MODE ───────────────────────────────────
mode_performance() {
    [ "$CURRENT_STATE" = "performance" ] && return
    log "RESTORING: Performance Mode (Temp: ${TEMP}°C)"
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
        MAX=$(cat "$cpu/cpuinfo_max_freq" 2>/dev/null)
        write "$cpu/scaling_governor" "performance"
        write "$cpu/scaling_max_freq" "$MAX"
    done
    ADRENO=/sys/class/kgsl/kgsl-3d0
    [ -d "$ADRENO" ] && write "$ADRENO/devfreq/governor" "performance"
    CURRENT_STATE="performance"
}

# ── ENTER REDUCED MODE ───────────────────────────────────────
mode_reduced() {
    [ "$CURRENT_STATE" = "reduced" ] && return
    log "THERMAL REDUCE: Slight freq drop (Temp: ${TEMP}°C)"
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
        MAX=$(cat "$cpu/cpuinfo_max_freq" 2>/dev/null)
        write "$cpu/scaling_max_freq" "$(( MAX * 90 / 100 ))"
    done
    CURRENT_STATE="reduced"
}

# ── ENTER SAFE MODE ──────────────────────────────────────────
mode_safe() {
    [ "$CURRENT_STATE" = "safe" ] && return
    log "THERMAL SAFE MODE: Throttling to protect device (Temp: ${TEMP}°C)"
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
        write "$cpu/scaling_governor" "schedutil"
        MAX=$(cat "$cpu/cpuinfo_max_freq" 2>/dev/null)
        write "$cpu/scaling_max_freq" "$(( MAX * 75 / 100 ))"
    done
    ADRENO=/sys/class/kgsl/kgsl-3d0
    [ -d "$ADRENO" ] && write "$ADRENO/devfreq/governor" "msm-adreno-tz"
    prop "persist.sys.hyperax.thermal_safe" "1"
    am broadcast -a "com.hyperax.THERMAL_SAFE" 2>/dev/null
    CURRENT_STATE="safe"
}

# ── ENTER EMERGENCY MODE ─────────────────────────────────────
mode_emergency() {
    log "!!! EMERGENCY THERMAL: ${TEMP}°C — HARD PROTECT !!!"
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
        write "$cpu/scaling_governor" "powersave"
        MIN=$(cat "$cpu/cpuinfo_min_freq" 2>/dev/null)
        write "$cpu/scaling_max_freq" "$MIN"
    done
    for zone in /sys/class/thermal/thermal_zone*/mode; do
        write "$zone" "enabled"
    done
    CURRENT_STATE="emergency"
}

# ═══════════════════════════════════════════════════════════════
# WATCHDOG LOOP
# ═══════════════════════════════════════════════════════════════
log "THERMAL GUARD STARTED — Polling every 3s"

while true; do
    TEMP=$(get_temp)
    log "TEMP: ${TEMP}°C | STATE: $CURRENT_STATE"

    if   [ "$TEMP" -ge "$TEMP_EMERGENCY" ]; then
        mode_emergency
        sleep 1
    elif [ "$TEMP" -ge "$TEMP_CRITICAL" ]; then
        mode_safe
        sleep 2
    elif [ "$TEMP" -ge "$TEMP_THROTTLE" ]; then
        mode_safe
        sleep 3
    elif [ "$TEMP" -ge "$TEMP_REDUCE" ]; then
        mode_reduced
        sleep 3
    else
        # Cool enough — restore performance
        if [ "$CURRENT_STATE" != "performance" ] && [ "$TEMP" -le "$TEMP_RESUME" ]; then
            mode_performance
        fi
        sleep 3
    fi
done
