#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — AUTO APPLY ENGINE
#  Developer : Gailo Willy | Version: v1.0.0
#  Trigger   : BOOT_COMPLETED (service.sh calls this)
#  Shell     : BusyBox ASH Standalone Mode
# ═══════════════════════════════════════════════════════════════

MODDIR=${0%/*}
LOG=/data/local/tmp/hyperax_apply.log
CONFIG="$MODDIR/config"

# ── LOGGER ───────────────────────────────────────────────────
log()  { echo "[$(date '+%H:%M:%S')] [INFO]  $1" >> "$LOG"; }
warn() { echo "[$(date '+%H:%M:%S')] [WARN]  $1" >> "$LOG"; }
err()  { echo "[$(date '+%H:%M:%S')] [ERROR] $1" >> "$LOG"; }
sep()  { echo "────────────────────────────────────" >> "$LOG"; }

# ── WRITE HELPER (safe write, no crash on missing node) ──────
write() {
    if [ -f "$1" ] || [ -c "$1" ]; then
        echo "$2" > "$1" 2>/dev/null
        log "SET $1 = $2"
    else
        warn "MISSING: $1"
    fi
}

# ── SETPROP HELPER ───────────────────────────────────────────
prop() { setprop "$1" "$2" 2>/dev/null && log "PROP $1 = $2"; }

# ═══════════════════════════════════════════════════════════════
# BOOT LOG HEADER
# ═══════════════════════════════════════════════════════════════
> "$LOG"
sep
log " HYPER AX MANAGER v1.0.0"
log " Developer: Gailo Willy"
log " Boot Apply Engine — START"
sep

# ═══════════════════════════════════════════════════════════════
# STEP 1: DETECT CHIPSET
# ═══════════════════════════════════════════════════════════════
detect_chipset() {
    SOC=$(getprop ro.board.platform)
    HARDWARE=$(getprop ro.hardware)
    BRAND=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')

    case "$SOC" in
        sm8650|sm8550|sm8475|sm8450|sm8350|sm8250|sm8150|\
        kona|lahaina|taro|kalama|pineapple|crow|cliffs)
            CHIPSET="snapdragon_8xx"
            ;;
        sm7675|sm7550|sm7450|sm7350|sm7325|sm7225)
            CHIPSET="snapdragon_7xx"
            ;;
        mt6989|mt6985|mt6983|mt6981|mt6979|\
        mt6895|mt6893|mt6891|mt6885|mt6877|mt6875)
            CHIPSET="mediatek"
            ;;
        exynos2400|exynos2200|exynos2100|exynos990|exynos9825|\
        s5e9935|s5e9925|s5e9835|s5e8535)
            CHIPSET="exynos"
            ;;
        *)
            CHIPSET="generic"
            warn "Unknown SOC: $SOC — using generic path"
            ;;
    esac

    log "CHIPSET: $CHIPSET | SOC: $SOC | BRAND: $BRAND"
}

# ═══════════════════════════════════════════════════════════════
# STEP 2: DETECT DISPLAY MAX Hz
# ═══════════════════════════════════════════════════════════════
detect_display_hz() {
    DETECTED_HZ=60

    # Try DRM sysfs
    for drm_modes in /sys/class/drm/*/modes; do
        [ -f "$drm_modes" ] || continue
        hz=$(grep -oE '[0-9]+\.[0-9]+' "$drm_modes" | sort -rn | head -1 | cut -d. -f1)
        [ -n "$hz" ] && DETECTED_HZ=$hz && break
    done

    # Fallback: framebuffer
    if [ "$DETECTED_HZ" -le 60 ] && [ -f /sys/class/graphics/fb0/modes ]; then
        hz=$(grep -oE '[0-9]+\.[0-9]+' /sys/class/graphics/fb0/modes | sort -rn | head -1 | cut -d. -f1)
        [ -n "$hz" ] && DETECTED_HZ=$hz
    fi

    # Fallback: system property
    if [ "$DETECTED_HZ" -le 60 ]; then
        hz=$(getprop ro.surface_flinger.max_frame_buffer_acquired_buffers)
        [ -z "$hz" ] && hz=120
        DETECTED_HZ=120
    fi

    log "DISPLAY MAX HZ DETECTED: ${DETECTED_HZ}Hz"
}

# ═══════════════════════════════════════════════════════════════
# STEP 3: APPLY CPU TWEAKS
# ═══════════════════════════════════════════════════════════════
apply_cpu() {
    sep
    log "APPLYING CPU TWEAKS"

    # Force performance governor + max freq on all cores
    for cpu_path in /sys/devices/system/cpu/cpu*/cpufreq; do
        [ -d "$cpu_path" ] || continue
        MAX=$(cat "$cpu_path/cpuinfo_max_freq" 2>/dev/null)
        write "$cpu_path/scaling_governor" "performance"
        write "$cpu_path/scaling_max_freq" "$MAX"
        write "$cpu_path/scaling_min_freq" "$(( MAX * 60 / 100 ))"
    done

    # Scheduler
    write /proc/sys/kernel/sched_boost 1
    write /proc/sys/kernel/sched_migration_cost_ns 50000
    write /proc/sys/kernel/sched_min_granularity_ns 400000
    write /proc/sys/kernel/sched_wakeup_granularity_ns 500000
    write /proc/sys/kernel/sched_latency_ns 1000000
    write /proc/sys/kernel/sched_child_runs_first 1
    write /proc/sys/kernel/perf_cpu_time_max_percent 30

    # DMA latency (input lag)
    write /dev/cpu_dma_latency 0

    # IRQ affinity — pin IRQs to big cores
    echo 0f > /proc/irq/default_smp_affinity 2>/dev/null

    # LPM — disable deep CPU idle sleep
    write /sys/module/lpm_levels/parameters/sleep_disabled 1

    # Snapdragon specific
    if [ "$CHIPSET" = "snapdragon_8xx" ] || [ "$CHIPSET" = "snapdragon_7xx" ]; then
        write /sys/module/cpu_boost/parameters/input_boost_enabled 1
        write /sys/module/cpu_boost/parameters/input_boost_ms 2000
        write /sys/module/msm_performance/parameters/touchboost 1
        write /proc/sys/kernel/sched_use_walt_cpu_util 1
        write /proc/sys/kernel/sched_use_walt_task_util 1
        write /proc/sys/kernel/sched_walt_cpu_high_irqload 1
        write /proc/sys/kernel/sched_boost_top_app 1
    fi

    # MediaTek specific
    if [ "$CHIPSET" = "mediatek" ]; then
        write /proc/perfmgr/eas/prefer_idle 1
        write /sys/module/mtk_perfmgr/parameters/enable 0
        for plat in /proc/mtk_thermal_monitor*; do
            write "$plat/enable" 0
        done
    fi

    log "CPU TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# STEP 4: APPLY GPU TWEAKS
# ═══════════════════════════════════════════════════════════════
apply_gpu() {
    sep
    log "APPLYING GPU TWEAKS"

    # ADRENO (Snapdragon)
    ADRENO=/sys/class/kgsl/kgsl-3d0
    if [ -d "$ADRENO" ]; then
        GPU_MAX=$(cat "$ADRENO/max_gpuclk" 2>/dev/null || cat "$ADRENO/gpuclk" 2>/dev/null)
        write "$ADRENO/devfreq/governor" "performance"
        write "$ADRENO/max_gpuclk" "$GPU_MAX"
        write "$ADRENO/min_clock_mhz" "$(cat $ADRENO/max_clock_mhz 2>/dev/null)"
        write "$ADRENO/default_pwrlevel" "1"
        write "$ADRENO/force_clk_on" "1"
        write "$ADRENO/force_bus_on" "1"
        write "$ADRENO/force_rail_on" "1"
        write "$ADRENO/force_clk_on_nap" "1"
        write "$ADRENO/bus_split" "0"
        write "$ADRENO/adreno_idler_active" "0"
        write "$ADRENO/throttling" "0"
        log "ADRENO GPU tuned"
    fi

    # MALI (MediaTek / Exynos)
    for mali in /sys/class/misc/mali0 /sys/devices/platform/*/mali.*/; do
        [ -d "$mali" ] || continue
        write "$mali/power_policy" "always_on"
        write "$mali/dvfs_enable" "0"
        MALI_MAX=$(cat "$mali/max_freq" 2>/dev/null || cat "$mali/highest_level" 2>/dev/null)
        [ -n "$MALI_MAX" ] && write "$mali/cur_freq" "$MALI_MAX"
        log "MALI GPU tuned: $mali"
    done

    # Vulkan / Skia
    prop "debug.hwui.renderer" "skiavk"
    prop "debug.hwui.skia_atrace_enabled" "false"
    prop "debug.sf.hw" "1"
    prop "debug.egl.hw" "1"
    prop "debug.performance.tuning" "1"

    log "GPU TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# STEP 5: DISABLE THERMAL THROTTLING
# ═══════════════════════════════════════════════════════════════
apply_thermal() {
    sep
    log "APPLYING THERMAL CONTROL"

    # Stop thermal daemons
    for svc in thermal-engine thermald thermal_manager mi_thermald vendor.thermal-manager qmi-thermal-main; do
        stop "$svc" 2>/dev/null && log "STOPPED: $svc"
    done

    # Disable thermal via sysfs
    for zone in /sys/class/thermal/thermal_zone*/; do
        write "${zone}mode" "disabled"
    done

    # MTK throttle
    write /proc/mtk_cooler_bcct/bcct_stop 1
    write /proc/mtk_thermal_throttle/throttle_temp 200000
    write /sys/kernel/debug/mtk_ts_cpu/trip_temp 200000

    # Qualcomm thermal
    write /sys/module/msm_thermal/parameters/enabled "N"
    write /sys/module/msm_thermal/core_control/enabled 0

    log "THERMAL THROTTLE DISABLED (Safe Mode Watchdog Active)"
}

# ═══════════════════════════════════════════════════════════════
# STEP 6: FORCE MAX REFRESH RATE + FPS
# ═══════════════════════════════════════════════════════════════
apply_fps_hz() {
    sep
    log "FORCING MAX FPS + ${DETECTED_HZ}Hz"

    # SurfaceFlinger tweaks
    prop "debug.sf.recomputecrop"      "0"
    prop "debug.sf.disable_backpressure" "1"
    prop "debug.sf.early_phase_offset_ns" "1000000"
    prop "debug.sf.early_app_phase_offset_ns" "1000000"
    prop "debug.sf.late_app_phase_offset_ns" "500000"
    prop "debug.sf.present_time_offset_from_vsync_ns" "0"
    prop "debug.sf.treat_170m_as_sRGB" "1"

    # Frame rate unlock
    prop "ro.surface_flinger.max_frame_buffer_acquired_buffers" "3"
    prop "ro.sf.override_null_vsync_period" "0"

    # Display Hz via hwc
    prop "debug.hwc.ignore_hdr_extended_range" "0"
    prop "persist.sys.performance_mode" "1"

    # Game mode performance level
    prop "persist.game_mode.performance" "2"

    # Vendor-specific Hz force
    case "$BRAND" in
        xiaomi|redmi|poco)
            prop "persist.vendor.display.miui.composer.enable" "false"
            prop "ro.vendor.display.touch.idle" "0"
            prop "persist.vendor.display.idle_time" "0"
            prop "persist.vendor.display.idle_time_inactive" "0"
            prop "debug.sf.hw" "1"
            log "XIAOMI/MIUI: Max Hz forced"
            ;;
        samsung)
            prop "debug.hwc.scenario_max_framerate" "$DETECTED_HZ"
            prop "debug.hwc.min_light_sensor_mode" "0"
            log "SAMSUNG/ONEUI: Max Hz forced"
            ;;
        oppo|realme|oneplus)
            prop "persist.sys.oplus.aod_fps_lock" "0"
            prop "debug.hwc.refresh_rate_override" "$DETECTED_HZ"
            log "OPPO/REALME/ONEPLUS: Max Hz forced"
            ;;
        vivo|iqoo)
            prop "persist.vivo.display.refresh_rate" "$DETECTED_HZ"
            log "VIVO/IQOO: Max Hz forced"
            ;;
    esac

    # Generic Hz node write
    for hz_node in \
        /sys/class/drm/card0-DSI-1/max_refresh_rate \
        /sys/kernel/debug/drm/debug_max_hz \
        /sys/class/graphics/fb0/refresh_rate; do
        write "$hz_node" "$DETECTED_HZ"
    done

    log "FPS + Hz TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# STEP 7: MEMORY / RAM OPTIMIZATION
# ═══════════════════════════════════════════════════════════════
apply_ram() {
    sep
    log "APPLYING RAM OPTIMIZATION"

    # VM tuning for gaming
    write /proc/sys/vm/swappiness 10
    write /proc/sys/vm/vfs_cache_pressure 50
    write /proc/sys/vm/dirty_ratio 20
    write /proc/sys/vm/dirty_background_ratio 5
    write /proc/sys/vm/dirty_expire_centisecs 3000
    write /proc/sys/vm/overcommit_memory 1
    write /proc/sys/vm/min_free_kbytes 51200
    write /proc/sys/vm/extra_free_kbytes 10240

    # Kill cached background apps aggressively
    prop "ro.lmk.low" "1001"
    prop "ro.lmk.medium" "800"
    prop "ro.lmk.critical" "0"
    prop "ro.lmk.critical_upgrade" "false"
    prop "ro.lmk.upgrade_pressure" "100"
    prop "ro.lmk.downgrade_pressure" "100"
    prop "ro.lmk.kill_heaviest_task" "true"

    log "RAM TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# STEP 8: NETWORK LATENCY OPTIMIZATION
# ═══════════════════════════════════════════════════════════════
apply_network() {
    sep
    log "APPLYING NETWORK TWEAKS"

    write /proc/sys/net/ipv4/tcp_fastopen 3
    write /proc/sys/net/ipv4/tcp_tw_reuse 1
    write /proc/sys/net/ipv4/tcp_timestamps 0
    write /proc/sys/net/ipv4/tcp_no_delay_ack 1
    write /proc/sys/net/core/rmem_max 16777216
    write /proc/sys/net/core/wmem_max 16777216
    write /proc/sys/net/core/netdev_max_backlog 5000

    prop "net.tcp.default_init_rwnd" "60"

    log "NETWORK TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# STEP 9: AUDIO LATENCY TWEAKS
# ═══════════════════════════════════════════════════════════════
apply_audio() {
    sep
    log "APPLYING AUDIO TWEAKS"

    prop "af.fast_track_multiplier" "1"
    prop "audio.deep_buffer.media" "false"
    prop "audio_hal.period_size" "192"
    prop "audio_hal.period_multiplier" "2"
    prop "ro.audio.flinger_standbytime_ms" "300"
    prop "media.stagefright.audio.deep" "false"

    log "AUDIO TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# STEP 10: INPUT / TOUCH LATENCY
# ═══════════════════════════════════════════════════════════════
apply_input() {
    sep
    log "APPLYING INPUT TWEAKS"

    prop "debug.input.miui_touch_boost" "1"
    prop "ro.min_pointer_dur" "0"
    prop "ro.max_pointer_layer_count" "16"
    prop "persist.sys.scrollingcache" "3"
    prop "windowsmgr.max_events_per_sec" "240"

    # Touch boost
    write /sys/module/cpu_boost/parameters/input_boost_enabled 1
    write /sys/module/cpu_boost/parameters/input_boost_ms 2000

    log "INPUT TWEAKS DONE"
}

# ═══════════════════════════════════════════════════════════════
# MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════
detect_chipset
detect_display_hz
apply_cpu
apply_gpu
apply_thermal
apply_fps_hz
apply_ram
apply_network
apply_audio
apply_input

sep
log "HYPER AX MANAGER — ALL TWEAKS APPLIED SUCCESSFULLY"
log "MAX Hz: ${DETECTED_HZ}Hz | MIN FPS TARGET: 120"
log "Chipset: $CHIPSET | Brand: $BRAND"
sep

# Launch thermal guard watchdog in background
sh "$MODDIR/scripts/thermal_guard.sh" &

exit 0
