#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — CUSTOMIZE (INSTALL) SCRIPT
#  Developer : Gailo Willy | v1.0.0
#  Runs at   : Flash/Install time inside AxManager
#  Note      : Uses $MODPATH, NOT MODDIR=${0%/*}
# ═══════════════════════════════════════════════════════════════

ui_print ""
ui_print "  ██╗  ██╗██╗   ██╗██████╗ ███████╗██████╗ "
ui_print "  ██║  ██║╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗"
ui_print "  ███████║ ╚████╔╝ ██████╔╝█████╗  ██████╔╝"
ui_print "  ██╔══██║  ╚██╔╝  ██╔═══╝ ██╔══╝  ██╔══██╗"
ui_print "  ██║  ██║   ██║   ██║     ███████╗██║  ██║"
ui_print "  ╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚══════╝╚═╝  ╚═╝"
ui_print ""
ui_print "  ██╗  ██╗██╗  ██╗"
ui_print "  ██║  ██║╚██╗██╔╝"
ui_print "  ███████║ ╚███╔╝ "
ui_print "  ██╔══██║ ██╔██╗ "
ui_print "  ██║  ██║██╔╝ ██╗"
ui_print "  ╚═╝  ╚═╝╚═╝  ╚═╝"
ui_print ""
ui_print "  ┌─────────────────────────────────────┐"
ui_print "  │      HYPER AX MANAGER  v1.0.0       │"
ui_print "  │   Premium AI Gaming Performance     │"
ui_print "  │      Developer: Gailo Willy          │"
ui_print "  └─────────────────────────────────────┘"
ui_print ""
ui_print "  [*] Detecting device info..."

# Print device info
ui_print "  [+] Brand  : $(getprop ro.product.brand)"
ui_print "  [+] Model  : $(getprop ro.product.model)"
ui_print "  [+] Android: $(getprop ro.build.version.release)"
ui_print "  [+] SOC    : $(getprop ro.board.platform)"
ui_print "  [+] ABI    : $ARCH"
ui_print "  [+] API    : $API"
ui_print ""

# Check minimum Android version
if [ "$API" -lt 29 ]; then
    abort "  [!] Android 10+ required (API 29+). Install aborted."
fi

ui_print "  [*] Installing module files..."

# Set execute permissions on all scripts
set_perm_recursive "$MODPATH/scripts" root root 0755 0644
set_perm "$MODPATH/scripts/auto_apply.sh"  root root 0755
set_perm "$MODPATH/scripts/game_boost.sh"  root root 0755
set_perm "$MODPATH/scripts/thermal_guard.sh" root root 0755
set_perm "$MODPATH/service.sh"   root root 0755
set_perm "$MODPATH/action.sh"    root root 0755
set_perm "$MODPATH/uninstall.sh" root root 0755

ui_print "  [+] Permissions set"
ui_print ""

# Detect max Hz
DETECTED_HZ=60
for drm in /sys/class/drm/*/modes; do
    [ -f "$drm" ] || continue
    hz=$(grep -oE '[0-9]+\.[0-9]+' "$drm" | sort -rn | head -1 | cut -d. -f1)
    [ -n "$hz" ] && DETECTED_HZ=$hz && break
done
[ "$DETECTED_HZ" -le 60 ] && DETECTED_HZ=120

ui_print "  [+] Display Max Hz Detected: ${DETECTED_HZ}Hz"
ui_print "  [+] FPS Target: 120 minimum | Max: ${DETECTED_HZ}"
ui_print ""
ui_print "  [*] Module installed!"
ui_print "  [*] Tweaks will auto-apply on next boot."
ui_print "  [*] Or tap ACTION button in AxManager now."
ui_print ""
ui_print "  ┌─────────────────────────────────────┐"
ui_print "  │  MAX FPS | MAX Hz | MAX PERFORMANCE  │"
ui_print "  │         by Gailo Willy               │"
ui_print "  └─────────────────────────────────────┘"
ui_print ""
