#!/system/bin/sh
# ═══════════════════════════════════════════════════════════════
#  HYPER AX MANAGER — UNINSTALL SCRIPT
#  Developer : Gailo Willy | v1.0.0
# ═══════════════════════════════════════════════════════════════

# Restore thermal daemons
for svc in thermal-engine thermald thermal_manager mi_thermald; do
    start "$svc" 2>/dev/null
done

# Re-enable thermal zones
for zone in /sys/class/thermal/thermal_zone*/mode; do
    echo "enabled" > "$zone" 2>/dev/null
done

# Restore schedutil governor
for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    echo "schedutil" > "$cpu/scaling_governor" 2>/dev/null
done

# Remove logs
rm -f /data/local/tmp/hyperax_*.log

echo "Hyper Ax Manager uninstalled. Thermal protection restored."
